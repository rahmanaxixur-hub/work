# 2_etl_gcs_to_bq

Project for ETL from Google Cloud Storage to BigQuery.

## Setup

- Python virtual environment managed by Poetry
- Environment variables in `.env`

## Usage

Add usage instructions here.

`
cd infra
docker compose build
docker compose up airflow-init
docker compose up -d

hen, open Airflow UI:
http://localhost:8080

Login:

username: airflow
password: airflow
`
